from setuptools import setup

setup(name='gym_snake',
      version='0.0.1',
      author="Satchel Grant",
      install_requires=['gym', 'numpy', 'matplotlib'],
      python_requires='>=3',
)
