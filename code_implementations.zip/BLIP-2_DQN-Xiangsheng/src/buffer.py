import random
from collections import deque, namedtuple
import pickle  # For efficient serialization

Transition = namedtuple('Transition', ('state', 'action', 'next_state', 'reward'))

class ReplayBuffer:
    def __init__(self, capacity, batch_size):
        self.capacity = capacity
        self.batch_size = batch_size
        self.memory = deque([], maxlen=capacity)

    def push(self, *args):
        """Save a transition, serializing images for memory efficiency."""
        state, action, next_state, reward = args
        # Serialize state and next_state (if not None) to save memory
        serialized_state = pickle.dumps(state)
        serialized_next_state = pickle.dumps(next_state) if next_state is not None else None
        self.memory.append(Transition(serialized_state, action, serialized_next_state, reward))

    def sample(self):
        # Deserialize sampled transitions
        sampled_transitions = random.sample(self.memory, self.batch_size)
        return [
            Transition(
                pickle.loads(t.state),
                t.action,
                pickle.loads(t.next_state) if t.next_state is not None else None,
                t.reward
            )
            for t in sampled_transitions
        ]

    def __len__(self):
        return len(self.memory)

    def clear(self):
        self.memory = deque([], maxlen=self.capacity)
        return self
