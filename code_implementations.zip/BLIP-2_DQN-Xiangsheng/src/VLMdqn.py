import os
import gym
import torch
import numpy as np
import torch.nn as nn
from itertools import count
from torch.optim import Optimizer
from loguru import logger
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime
from src.utils import device
from src.networks import ValueFunctionQ
from src.buffer import ReplayBuffer, Transition
from transformers import Blip2Processor, Blip2ForConditionalGeneration

DEVICE = device()
EPS_END: float = 0.01
EPS_START: float = 1.0
EPS_DECAY: float = 0.999_9
eps: float = EPS_START

Blip2_processor = Blip2Processor.from_pretrained("Salesforce/blip2-opt-2.7b")
Blip2_model = Blip2ForConditionalGeneration.from_pretrained("Salesforce/blip2-opt-2.7b", 
                                                            load_in_8bit=True,
                                                            device_map={"": 0}, 
                                                            torch_dtype=torch.float32)

def tensor(x: np.array, type=torch.float32, device=DEVICE) -> torch.Tensor:
    return torch.as_tensor(x, dtype=type, device=device)

# simple MSE loss
def loss(value_batch: torch.Tensor, target_batch: torch.Tensor) -> torch.Tensor:
    mse = nn.MSELoss()
    return mse(value_batch, target_batch)
    
def optimize_Q(Q: ValueFunctionQ, target_Q: ValueFunctionQ, gamma: float, memory: ReplayBuffer, optimizer: Optimizer):
    if len(memory) < memory.batch_size: return
    batch_transitions = memory.sample()
    batch = Transition(*zip(*batch_transitions))
    states = np.stack(batch.state)
    actions = np.stack(batch.action)
    rewards = np.stack(batch.reward)
    valid_next_states = np.stack(tuple(filter(lambda s: s is not None, batch.next_state)))
    nonterminal_mask = tensor(tuple(map(lambda s: s is not None, batch.next_state)), type=torch.bool)
    rewards = tensor(rewards)
    actions = tensor(actions, type=torch.long).unsqueeze(1) 
    # Initialize targets with zeros
    targets = torch.zeros(size=(memory.batch_size, 1), device=DEVICE)

    with torch.no_grad():
        next_Q = target_Q(valid_next_states)
        # Take the max Q-value over actions for each next state
        max_next_Q = next_Q.max(1)[0].unsqueeze(1)
        # Add rewards and discounted future Q-values
        targets[nonterminal_mask] = rewards[nonterminal_mask].unsqueeze(1) + gamma * max_next_Q
    # Compute the loss between the current Q-values and target Q-values
    Q_values = Q(states).gather(1, actions)
    loss_value = loss(Q_values, targets)
    # Perform backpropagation and update the Q-network
    optimizer.zero_grad()
    loss_value.backward()
    optimizer.step()

def save_image_for_debugging(image, answer, folder="images_output"):
    """
    Saves the given image as a PNG file in the specified folder.
    Each image is timestamped to avoid overwriting.
    """
    # Ensure the folder exists
    os.makedirs(folder, exist_ok=True)

    # Generate a unique filename using a timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    filename = os.path.join(folder, f"image_{timestamp}.png")

    # Create a drawing object to overlay the text
    draw = ImageDraw.Draw(image)
    
    # Set font (use default font or specify a TTF font file)
    try:
        font = ImageFont.truetype("arial.ttf", 20)  # Adjust font size
    except IOError:
        font = ImageFont.load_default()  # Use default font if arial is not available

    # Calculate the bounding box for the text to determine its width and height
    bbox = draw.textbbox((0, 0), answer, font=font)
    text_width = bbox[2] - bbox[0]  # width of the text
    text_height = bbox[3] - bbox[1]  # height of the text

    # Calculate position: Centered horizontally, near the bottom of the image
    position = (image.width // 2 - text_width // 2, image.height - text_height - 10)

    # Draw the text on the image
    draw.text(position, answer, font=font, fill="red")

    # Save the image with the overlaid text
    image.save(filename, format="PNG")

def eps_greedy_sample(Q: ValueFunctionQ, state: np.array):
    global eps
    eps = max(EPS_END, EPS_DECAY * eps)
    # With probability eps, select a random action
    # With probability (1 - eps), select the best action using greedy_sample
    if np.random.rand() < 1 - eps:
        with torch.no_grad():
            return Q.action(state)
    else:
        return np.random.randint(0, Q.network[-1].out_features)

def get_feedback(image):
    """
    Takes a PIL Image, processes it through the Blip2 model,
    and returns an action.
    """
    raw_image = Image.fromarray(image).convert('RGB')

    # Prompt
    # prompt = f"Tell me what is happening in this picture."
    # prompt = f"In this photo, how far in km is the purple space shuttle in relative to the yellow flags?"
    prompt = f"Analyze the landing situation of the space shuttle in terms of its position to the snow surface inside flags."

    inputs = Blip2_processor(images=raw_image, 
                             text=f"Question: {prompt} Answer:", 
                             return_tensors="pt").to(DEVICE, dtype=torch.float32)

    # Generate the output text from the Blip2 model
    generated_ids = Blip2_model.generate(**inputs)
    generated_text = Blip2_processor.batch_decode(generated_ids, skip_special_tokens=True)[0].strip()
    answer = generated_text.split("Answer:")[1].strip()
    # logger.info(f"Blip2 answer: {answer}")
    
    # Save the image for debugging
    # save_image_for_debugging(raw_image, answer)

    # Analyze the generated answer and assign feedback points
    feedback = -0.1
    if "center" in answer.lower() or "middle" in answer.lower():
        feedback += 1.25  # Good positioning
    if "inside" in answer.lower() or "within" in answer.lower():
        feedback += 2.75  # Within the correct area
    if "on" in answer.lower() or "landed" in answer.lower():
        feedback += 0.45  # Positive for landing on the surface
    if "outside" in answer.lower() or "away" in answer.lower():
        feedback -= 1.75  # Penalize for incorrect positioning
    # Feedback based on stability
    if "stable" in answer.lower():
        feedback += 0.75  # bonus for stability
    if "unstable" in answer.lower():
        feedback -= 0.75  # penalty for instability

    return feedback

    
def train_one_epoch(env: gym.Env, Q: ValueFunctionQ, target_Q: ValueFunctionQ, memory: ReplayBuffer, optimizer: Optimizer, gamma: float = 0.99) -> float:
    # Make sure target isn't being trained
    Q.train()
    target_Q.eval()
    # Reset the environment and get a fresh observation
    state, info = env.reset()
    episode_reward: float = 0.0
    weight = 0.15
    for t in count():
        # Select an action using epsilon-greedy sampling
        action = eps_greedy_sample(Q, state)
        if t % 10 == 0:
            # Get rendered image
            image = env.render()
            feedback = get_feedback(image)

        # Step the environment
        next_state, reward, done, truncated, _= env.step(action)
        episode_reward += (1-weight)*reward + weight*feedback

        terminated = done or truncated

        if terminated: next_state = None

        memory.push(state, action, next_state, reward)
        optimize_Q(Q, target_Q, gamma, memory, optimizer)
        
        # Move to the next state
        state = next_state
        if terminated: break

    return episode_reward